def basic_operations(num1, num2):
    addition = num1 + num2
    subtraction = num1 - num2
    multiplication = num1 * num2
    division = num1 / num2 if num2 != 0 else "Undefined (division by zero)"
    
    return addition, subtraction, multiplication, division

if __name__ == "__main__":

    try:
        number1 = float(input("Enter the first number: "))
        number2 = float(input("Enter the second number: "))
        
        add, sub, mul, div = basic_operations(number1, number2)
        
        # Displaying results
        print(f"Addition: {add}")
        print(f"Subtraction: {sub}")
        print(f"Multiplication: {mul}")
        print(f"Division: {div}")
        
    except ValueError:
        print("Please enter valid numbers.")
